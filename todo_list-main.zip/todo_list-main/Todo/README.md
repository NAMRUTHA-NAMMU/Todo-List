# Todo-list-with-php
A simple todo list with bootstrap and raw php

## How to run:
* create a database and name it "todo"
* upload 'todo.sql'  file in "todo" database
* and just simply run index.php with any browser 
* make sure you have active internet connection because i used bootstrap cdn . so without internet you will not show proper output

##some screenshoots
![](https://raw.githubusercontent.com/crrakib5/Todo-list-with-php/master/screenshoots/Screenshot%20(303).png)
![](https://raw.githubusercontent.com/crrakib5/Todo-list-with-php/master/screenshoots/Screenshot%20(304).png)
![](https://raw.githubusercontent.com/crrakib5/Todo-list-with-php/master/screenshoots/Screenshot%20(305).png)
![](https://raw.githubusercontent.com/crrakib5/Todo-list-with-php/master/screenshoots/Screenshot%20(306).png)
![](https://raw.githubusercontent.com/crrakib5/Todo-list-with-php/master/screenshoots/Screenshot%20(307).png)
